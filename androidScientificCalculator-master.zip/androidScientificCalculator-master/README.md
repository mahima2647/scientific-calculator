# AndroidScientificCalculator
![alt text](http://i.imgur.com/UcnsiCU.png)

An elegant feature-packed scientific calculator app for Android.
This project is now listed on the play store: https://play.google.com/store/apps/details?id=com.kumailn.calculator
